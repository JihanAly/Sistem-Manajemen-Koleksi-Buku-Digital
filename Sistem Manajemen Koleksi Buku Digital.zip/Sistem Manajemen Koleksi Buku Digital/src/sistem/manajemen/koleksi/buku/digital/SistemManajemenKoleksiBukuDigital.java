/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistem.manajemen.koleksi.buku.digital;


/**
 *
 * @author Asus
 */
public class SistemManajemenKoleksiBukuDigital {
    public static void main(String[] args) {
        Buku buku = new Buku();  // bikin objek Buku
        buku.menu();       
    }
}
